define (
    [
        'ko',
        'jquery',
        'Magento_Checkout/js/view/payment/default',
    ],
    function (ko, $, Component)
    {
        'use strict';
        return Component.extend(
            {
                defaults: {
                    template: 'JustBlink_FreePay/payment/freepay-payment'
                },
            }
        );
    }
);
