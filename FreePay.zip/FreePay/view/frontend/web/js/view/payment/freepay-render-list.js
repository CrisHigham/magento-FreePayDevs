define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'justblink_freepay',
                component:'JustBlink_FreePay/js/view/payment/method-renderer/freepay-method'
            }
        );
        return Component.extend({});
    }
)
