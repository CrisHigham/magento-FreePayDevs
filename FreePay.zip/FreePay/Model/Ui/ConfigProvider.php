<?php

namespace JustBlink\FreePay\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;

class ConfigProvider implements ConfigProviderInterface
{
    const CODE = "justblink_freepay";

    /**
     * @inheritDoc
     */
    public function getConfig()
    {
        $config =  [
                    'payment' => [
                        self::CODE => [
                            "key" => "value"
                        ]
                    ]
        ];
        return $config;
    }
}
