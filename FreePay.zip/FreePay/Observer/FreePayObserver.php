<?php

declare(strict_types=1);

namespace JustBlink\FreePay\Observer;

use Exception;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface as PsrLoggerInterface;

/**
 * Class MyObserver
 */
class FreePayObserver implements ObserverInterface
{
    /**
     * @var PsrLoggerInterface
     */
    private $logger;

    /**
     * MyObserver constructor.
     *
     * @param PsrLoggerInterface $logger
     */
    public function __construct(
        PsrLoggerInterface $logger
    )
    {
        $this->logger = $logger;
    }

    /**
     * Should you need to add extra payment information to the payment form,
     * This observer is to pull the payment information off the form and add it to the payload.
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        try {
            // some code goes here
        } catch (Exception $e) {
            $this->logger->error($e->getMessage());
        }
    }
}
