<?php

namespace JustBlink\FreePay\Gateway\Request;

use Magento\Payment\Gateway\Request\BuilderInterface;

class AuthorizationRequestBuilder implements BuilderInterface
{
    /** Function to build the request body. This can be substituted for a Composite Builder.
     * @param $buildSubject
     * @return string[]
     */
    public function build($buildSubject)
    {
        file_put_contents("debug.log", "JustBlink/FreePay/Gateway/Request/AuthorizationRequestBuilder.php - build()" . PHP_EOL);
        return [
            'Name' => 'JustBlink FreePay',
            'Function' => 'Request Builder',
        ];
    }
}
