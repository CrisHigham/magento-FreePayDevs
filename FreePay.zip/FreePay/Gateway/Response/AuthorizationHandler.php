<?php
/**
 * Copyright © 2022 - Dischem. All rights reserved.
 * See LICENSE.txt for license details.
 *
 * @author Cris Higham <cris@codeinfinity.co.za>
 */

namespace JustBlink\FreePay\Gateway\Response;

use Magento\Payment\Gateway\Response\HandlerInterface;

class AuthorizationHandler implements HandlerInterface
{
    public function handle(array $handlingSubject, array $response)
    {
        file_put_contents("debug.log", "JustBlink/FreePay/Gateway/Response/AuthorizationHandler.php - handle()" . PHP_EOL, FILE_APPEND);
        file_put_contents("debug.log", " - incoming response: " . print_r($response, true) . PHP_EOL, FILE_APPEND);
    }
}
