<?php

namespace JustBlink\FreePay\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;

class AuthorizeClient implements ClientInterface
{

    /**
     * @param TransferInterface $transferObject
     * @return array|void
     */
    public function placeRequest(TransferInterface $transferObject)
    {
        file_put_contents("debug.log", "JustBlink/FreePay/Gateway/Http/Client/AuthorizeClient.php - placeRequest()" . PHP_EOL, FILE_APPEND);
        // TODO: Implement placeRequest() method.
        $response = [];
        // Build out a data array for the curl request
        $data = $transferObject->getBody();
        file_put_contents("debug.log", "Incoming transfer body: " . print_r($data, true) . PHP_EOL, FILE_APPEND);
        try {
            $response = $this->process($data);
        } catch (\Exception $e) {
            $message = $e->getMessage() ? $e->getMessage() : "Something went wrong during Gateway request.";
        }
        return $response;
    }

    /**
     * Place the HTTP request
     * @return array
     */
    public function process($data)
    {
        $response = $data;
        file_put_contents("debug.log", "JustBlink/FreePay/Gateway/Http/Client/AuthorizeClient.php - process()" . PHP_EOL, FILE_APPEND);

        // @todo curl request goes here

        return $response;
    }
}



