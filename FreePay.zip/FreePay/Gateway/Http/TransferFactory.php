<?php

namespace JustBlink\FreePay\Gateway\Http;

use Magento\Payment\Gateway\Http\TransferBuilder;
use Magento\Payment\Gateway\Http\TransferFactoryInterface;
use Magento\Payment\Gateway\Http\TransferInterface;

class TransferFactory implements TransferFactoryInterface
{
    /**
     * @var TransferBuilder
     */
    private $transferBuilder;

    /**
     * @param TransferBuilder $transferBuilder
     */
    public function __construct(
        TransferBuilder $transferBuilder
    )
    {
        $this->transferBuilder = $transferBuilder;
    }

    /**
     * @param array $request
     * @return \Magento\Payment\Gateway\Http\Transfer|TransferInterface
     */
    public function create(array $request)
    {
        file_put_contents("debug.log", "JustBlink/FreePay/Gateway/Http/TransferFactory.php - create()" . PHP_EOL, FILE_APPEND);
        file_put_contents("debug.log", " - incoming Body: " . print_r($request, true) . PHP_EOL, FILE_APPEND);
        return $this->transferBuilder
            ->setMethod("POST")
            ->setUri("https://www.justblink.co.za/mirror.php")
            ->setBody($request)
            ->build();
    }
}
