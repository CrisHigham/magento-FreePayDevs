<?php

namespace JustBlink\FreePay\Gateway\Validator;

use Magento\Payment\Gateway\Validator\AbstractValidator;
use Magento\Payment\Gateway\Validator\ResultInterface;

class AuthorizationValidator extends AbstractValidator
{
    /**
     * Performs validation of result code
     *
     * @param array $validationSubject
     * @return ResultInterface
     */
    public function validate(array $validationSubject)
    {
        file_put_contents("debug.log", "JustBlink/FreePay/Gateway/Validator/AuthorizationValidator.php - validate()" . PHP_EOL, FILE_APPEND);

        // The return of true, will place the order
        return $this->createResult(
            true
        );
    }
}
